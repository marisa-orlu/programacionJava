package Logica;

import Gestion.Gestion;

public class App {

	public static void main(String[] args) {
		Gestion.iniciarAplicacion();
	}

}

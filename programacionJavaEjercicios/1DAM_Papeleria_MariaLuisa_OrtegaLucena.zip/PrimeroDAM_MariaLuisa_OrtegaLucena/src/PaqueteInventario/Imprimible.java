package PaqueteInventario;

public interface Imprimible {
	public void imprimirInventarioValorado();
}

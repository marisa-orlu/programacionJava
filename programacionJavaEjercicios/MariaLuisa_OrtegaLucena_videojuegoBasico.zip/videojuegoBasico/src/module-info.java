/**
 * 
 */
/**
 * 
 */
module videojuegoBasico {
}
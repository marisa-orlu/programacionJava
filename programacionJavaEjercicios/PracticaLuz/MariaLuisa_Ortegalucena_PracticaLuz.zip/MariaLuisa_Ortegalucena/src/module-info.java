/**
 * 
 */
/**
 * 
 */
module PracticaLuz {
}
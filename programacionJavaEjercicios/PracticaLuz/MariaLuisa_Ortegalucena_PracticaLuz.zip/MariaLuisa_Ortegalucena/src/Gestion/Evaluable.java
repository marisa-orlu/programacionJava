package Gestion;

public interface Evaluable {
	public void evaluarImpacto();
}

package ejercicio1;

public class lineaTetris {

	public static void main(String[] args) {
		int[][] matriz = new int[5][7];

	}

}

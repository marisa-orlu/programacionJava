package Gestion;

public interface Mostrable {
	public String resumen();
}

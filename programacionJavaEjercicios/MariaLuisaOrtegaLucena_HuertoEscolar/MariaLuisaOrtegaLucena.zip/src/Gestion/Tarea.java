package Gestion;

public interface Tarea {
	void realizar();
}

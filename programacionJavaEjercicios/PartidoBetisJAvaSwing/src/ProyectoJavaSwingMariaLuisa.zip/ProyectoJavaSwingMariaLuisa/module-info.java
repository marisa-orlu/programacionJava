/**
 * 
 */
/**
 * 
 */
module PartidoBetisJAvaSwing {
	requires java.desktop;
}
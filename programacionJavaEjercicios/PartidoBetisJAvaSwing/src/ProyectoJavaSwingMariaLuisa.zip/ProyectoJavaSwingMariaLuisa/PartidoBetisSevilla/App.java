package PartidoBetisSevilla;

public class App {

	public static void main(String[] args) {
		VentanaPartido ventana = new VentanaPartido();
	}
}
